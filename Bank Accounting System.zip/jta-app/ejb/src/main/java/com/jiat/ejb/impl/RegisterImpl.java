package com.jiat.ejb.impl;

import com.jiat.ejb.entity.User;
import com.jiat.ejb.remote.Register;
import jakarta.ejb.Stateless;
import jakarta.ejb.TransactionAttribute;
import jakarta.ejb.TransactionAttributeType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Stateless
public class RegisterImpl implements Register {

    @PersistenceContext(unitName = "WebPU")
    private EntityManager em;

    @Override
    @TransactionAttribute(TransactionAttributeType.NEVER)
    public boolean register(String name, String email, String password) {

        User user = new User();
        user.setName("Lakshan");
        user.setEmail("lakshan@gmail.com");
        user.setPassword("1234");

       // em.persist(user);

        return false;
    }
}
