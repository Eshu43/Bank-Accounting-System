package com.jiat.ejb.remote;

import jakarta.ejb.Remote;

@Remote
public interface UserService {
    void method1();
    void method2();
    void method3();
    void method4();
    void method5();
}
